#pragma once
# include <vector>
# include <GL/glew.h>

// class to hold positions for each object

class Coordinates
{
public:
	// return object functions
	static std::vector<GLfloat>* getHouseCoords();
	static std::vector<GLfloat>* getFoundationCoords();
	static std::vector<GLfloat>* getPlaneCoords();
	static std::vector<GLfloat>* getRoofCoords();
	static std::vector<GLfloat>* getLampostCoords();
	static std::vector<GLfloat>* getLamplightCoords();
	static std::vector<GLfloat>* getLightCoords();
	static std::vector<GLfloat>* getPyramidCoords();
};